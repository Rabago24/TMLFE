TMLFE - PAQUETE DE ESCUDOS NBA

Estructura incluida:
assets/logos/*.png

Uso en GitHub:
1. Abre la carpeta assets/logos de tu repositorio.
2. Pulsa Add file > Upload files.
3. Sube los 30 archivos PNG que hay dentro de assets/logos en este paquete.
4. Pulsa Commit changes.
5. Recarga teams.html con Ctrl+F5.

Todos los archivos están normalizados a 128x128 px con fondo transparente.
